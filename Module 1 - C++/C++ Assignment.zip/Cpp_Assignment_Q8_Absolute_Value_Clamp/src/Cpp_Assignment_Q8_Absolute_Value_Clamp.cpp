//============================================================================
// Name        : Cpp_Assignment_Q8_Absolute_Value_Clamp.cpp
// Author      : Omkar Velonde
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
/*
 * Q8. (Challenge) Absolute Value & Clamp — No if-else
Write two C++ functions using only the ternary operator (no if, no else, no standard library):
1. int absolute(int n) — returns the absolute value of n.
2. int clamp(int val, int lo, int hi) — returns:
lo if val < lo
hi if val > hi
val otherwise
Test with the following cases in main() and print results in a table format:
 */
#include <iostream>
using namespace std;

int absolute(int n){
	int result = (n>=0) ? n:  n*(-1) ;
	return result;
}

int clamp(int val, int lo, int hi){
	int result = (val<lo) ? lo : (val>hi) ? hi : val;

}
int main() {
	/*
	int val = -12;
	int lo = 10;
	int hi = 5;
	int abs_value = absolute(val);
	int c = clamp(val, lo, hi);
	cout << "Absolute value: " <<abs_value<< endl;
	cout << "Clamp: " <<c<< endl;
	*/

	int values[] = {-15, 0, 25, -3};
	int los[]    = {-10, -10, -10, 0};
	int his[]    = {10, 10, 10, 5};

    cout << "val\tlo\thi\tabsolute(val)\tclamp(val,lo,hi)\n";
    cout << "-----------------------------------------------------------\n";

    for(int i = 0; i < 4; i++) {
        cout << values[i] << "\t"
             << los[i] << "\t"
             << his[i] << "\t"
             << absolute(values[i]) << "\t\t"
             << clamp(values[i], los[i], his[i]) << "\n";
    }
	return 0;
}
